#!/bin/bash
echo "🏛️ Starting Sophia Governance API..."
source venv/bin/activate
python sophia_governance_api.py
